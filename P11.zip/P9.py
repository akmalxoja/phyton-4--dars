nums = [1, 2, 3]  # Input ro'yxati
num_str = ''.join(str(num) for num in nums)  
result = [int(digit) for digit in str(int(num_str) + 1)]  

print(result)  