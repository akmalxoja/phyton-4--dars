list1=[1, 2, 3]
list2=[11, 22, 33]
list3 = list()

for i in range(max(len(list1), len(list2))):
    
    list3.append(list1[i])
    
    list3.append(list2[i])

print(list3)
